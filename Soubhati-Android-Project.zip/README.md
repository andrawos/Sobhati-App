# سبحتي — Android WebView project

هذا المشروع يغلّف ملف `index.html` داخل تطبيق Android بسيط باستخدام WebView.

## بناء APK عبر GitHub Actions
1. أنشئ مستودع GitHub جديداً وارفع محتويات هذا المجلد إليه.
2. افتح تبويب Actions في المستودع.
3. شغّل workflow باسم **Build Soubhati APK** (أو ادفع commit إلى main).
4. بعد انتهاء البناء، افتح نتيجة التشغيل ونزّل Artifact باسم `soubhati-apk`.
5. فك ضغط Artifact وستجد `app-debug.apk` للتثبيت على هاتف Android.

ملاحظة: هذا مشروع بناء وليس APK مبنياً مسبقاً. يحتاج تشغيل workflow على GitHub لإنتاج ملف APK.
مواقيت الصلاة تحتاج اتصال إنترنت، والعداد يحفظ قيمته محلياً داخل التطبيق.
