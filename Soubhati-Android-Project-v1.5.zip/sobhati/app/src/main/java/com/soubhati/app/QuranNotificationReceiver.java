package com.soubhati.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class QuranNotificationReceiver extends BroadcastReceiver {
    private static final String ACTION = "com.soubhati.app.QURAN_NOTIFICATION";
    private static final String CHANNEL = "sobhati_quran_verses";
    private static final String PREFS = "sobhati_reminders";

    // نصوص مختارة مع مراجعها، محفوظة محلياً لتعمل الإشعارات دون اتصال.
    private static final String[][] VERSES = {
        {"وَقُل رَّبِّ زِدْنِي عِلْمًا","طه","114"},
        {"فَإِنَّ مَعَ الْعُسْرِ يُسْرًا","الشرح","5"},
        {"إِنَّ مَعَ الْعُسْرِ يُسْرًا","الشرح","6"},
        {"أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ","الرعد","28"},
        {"فَاذْكُرُونِي أَذْكُرْكُمْ","البقرة","152"},
        {"وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ","الحديد","4"},
        {"إِنَّ اللَّهَ مَعَ الصَّابِرِينَ","البقرة","153"},
        {"لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ","الزمر","53"},
        {"وَاللَّهُ خَيْرُ الرَّازِقِينَ","الجمعة","11"},
        {"إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ","البقرة","195"},
        {"وَقُلِ اعْمَلُوا فَسَيَرَى اللَّهُ عَمَلَكُمْ","التوبة","105"},
        {"وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ","هود","88"},
        {"إِنَّ اللَّهَ غَفُورٌ رَّحِيمٌ","البقرة","173"},
        {"وَبَشِّرِ الصَّابِرِينَ","البقرة","155"},
        {"إِنَّ اللَّهَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ","البقرة","20"},
        {"وَهُوَ أَرْحَمُ الرَّاحِمِينَ","يوسف","64"}
    };

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private static PendingIntent pending(Context c) {
        Intent i = new Intent(c, QuranNotificationReceiver.class).setAction(ACTION);
        return PendingIntent.getBroadcast(c, 202, i,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    public static void cancel(Context c) {
        AlarmManager a = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        a.cancel(pending(c));
    }

    public static void scheduleNext(Context c, boolean first) {
        android.content.SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("quran_enabled", false)) return;
        String day = today();
        int sent = p.getString("quran_day", "").equals(day) ? p.getInt("quran_sent_today", 0) : 0;
        int count = Math.max(1, Math.min(6, p.getInt("quran_daily_count", 3)));
        long now = System.currentTimeMillis();
        if (sent >= count) {
            // Keep the daily schedule alive: after today's quota, resume tomorrow at 09:00 local time.
            java.util.Calendar nextMorning = java.util.Calendar.getInstance();
            nextMorning.add(java.util.Calendar.DAY_OF_YEAR, 1);
            nextMorning.set(java.util.Calendar.HOUR_OF_DAY, 9);
            nextMorning.set(java.util.Calendar.MINUTE, 0);
            nextMorning.set(java.util.Calendar.SECOND, 0);
            nextMorning.set(java.util.Calendar.MILLISECOND, 0);
            Intent nextIntent = new Intent(c, QuranNotificationReceiver.class).setAction(ACTION);
            PendingIntent nextPi = pending(c);
            AlarmManager nextAlarm = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) nextAlarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextMorning.getTimeInMillis(), nextPi);
            else nextAlarm.set(AlarmManager.RTC_WAKEUP, nextMorning.getTimeInMillis(), nextPi);
            return;
        }
        long trigger;
        if (first || sent == 0) {
            long start = now + TimeUnit.MINUTES.toMillis(2);
            long end = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(12);
            trigger = start + (long)(Math.random() * Math.max(1, end - start));
        } else {
            long span = TimeUnit.HOURS.toMillis(12) / Math.max(1, count);
            trigger = now + span + (long)(Math.random() * TimeUnit.MINUTES.toMillis(35));
        }
        Intent i = new Intent(c, QuranNotificationReceiver.class).setAction(ACTION);
        PendingIntent pi = pending(c);
        AlarmManager a = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        else a.set(AlarmManager.RTC_WAKEUP, trigger, pi);
    }

    @Override public void onReceive(Context c, Intent intent) {
        android.content.SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            scheduleNext(c, true);
            return;
        }
        if (!p.getBoolean("quran_enabled", false)) return;

        String day = today();
        int sent = p.getString("quran_day", "").equals(day) ? p.getInt("quran_sent_today", 0) : 0;
        int count = Math.max(1, Math.min(6, p.getInt("quran_daily_count", 3)));
        if (sent >= count) return;

        int idx = (int)(Math.random() * VERSES.length);
        String[] verse = VERSES[idx];
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "آيات قرآنية", NotificationManager.IMPORTANCE_DEFAULT));
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 203, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("آية من القرآن الكريم")
            .setContentText(verse[0])
            .setStyle(new NotificationCompat.BigTextStyle().bigText(verse[0] + "\nسورة " + verse[1] + "، الآية " + verse[2]))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).setContentIntent(pi);
        nm.notify(3000 + sent, b.build());
        p.edit().putString("quran_day", day).putInt("quran_sent_today", sent + 1).apply();
        scheduleNext(c, false);
    }
}
