package com.soubhati.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 710;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false); settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new ReminderBridge(), "SobhatiAndroid");
        webView.setBackgroundColor(0xFFF4F7F2);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) { return assetLoader.shouldInterceptRequest(request.getUrl()); }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private class ReminderBridge {
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    if (!manager.canScheduleExactAlarms()) {
                        Intent permissionIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        try { startActivity(permissionIntent); } catch (Exception ignored) { }
                    }
                }
            });
        }
        @JavascriptInterface public void scheduleFajrReminder(long fajrMillis) {
            if (fajrMillis <= 0) return;
            long triggerAt = fajrMillis - 10L * 60L * 1000L;
            if (triggerAt <= System.currentTimeMillis()) triggerAt += 24L * 60L * 60L * 1000L;
            Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pending = PendingIntent.getBroadcast(MainActivity.this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putLong("next_fajr", fajrMillis).putBoolean("fajr_enabled", true).apply();
            AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) return;
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending);
            else alarm.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pending);
        }
        @JavascriptInterface public void scheduleQuranNotifications(int dailyCount) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
                int count = Math.max(1, Math.min(6, dailyCount));
                getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("quran_enabled", true).putInt("quran_daily_count", count).putInt("quran_sent_today", 0).putString("quran_day", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date())).apply();
                QuranNotificationReceiver.scheduleNext(MainActivity.this, true);
            });
        }
        @JavascriptInterface public void cancelQuranNotifications() {
            QuranNotificationReceiver.cancel(MainActivity.this);
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("quran_enabled", false).apply();
        }
        @JavascriptInterface public void cancelFajrReminder() {
            Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pending = PendingIntent.getBroadcast(MainActivity.this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pending);
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("fajr_enabled", false).remove("next_fajr").apply();
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
