package com.soubhati.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "sobhati_fajr";
    private static PendingIntent alarmIntent(Context context) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        return PendingIntent.getBroadcast(context, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }
    private static void scheduleNext(Context context) {
        android.content.SharedPreferences prefs = context.getSharedPreferences("sobhati_reminders", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("fajr_enabled", false)) return;
        long fajr = prefs.getLong("next_fajr", 0L);
        if (fajr <= 0) return;
        long nextFajr = fajr;
        while (nextFajr - 10L * 60L * 1000L <= System.currentTimeMillis()) nextFajr += 24L * 60L * 60L * 1000L;
        prefs.edit().putLong("next_fajr", nextFajr).apply();
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) return;
        long trigger = nextFajr - 10L * 60L * 1000L;
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, alarmIntent(context));
        else alarm.setExact(AlarmManager.RTC_WAKEUP, trigger, alarmIntent(context));
    }
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED".equals(intent.getAction())) {
            scheduleNext(context);
            return;
        }
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "تنبيه الفجر", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 100, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("اقترب وقت صلاة الفجر")
                .setContentText("بقيت عشر دقائق على أذان الفجر")
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        manager.notify(1001, notification.build());
        android.content.SharedPreferences prefs = context.getSharedPreferences("sobhati_reminders", Context.MODE_PRIVATE);
        long oldFajr = prefs.getLong("next_fajr", 0L);
        if (oldFajr > 0) prefs.edit().putLong("next_fajr", oldFajr + 24L * 60L * 60L * 1000L).apply();
        scheduleNext(context);
    }
}
