
const translations={
ar:{welcome:"السلام عليكم ورحمة الله وبركاته",tasbih:"السبحة الإلكترونية",count:"عدد التسبيحات",tap:"سَبِّح الآن",undo:"تراجع",reset:"تصفير",prayerTimes:"مواقيت الصلاة · القنيطرة",dailyHadith:"حديث اليوم",adhkarTitle:"الأذكار اليومية",morning:"أذكار الصباح",evening:"أذكار المساء",afterPrayer:"بعد الصلاة",qiblaTitle:"اتجاه القبلة",qiblaFrom:"الاتجاه التقريبي من القنيطرة",qiblaDesc:"نحو الشرق مع ميل قليل إلى الجنوب",qiblaNotice:"هذا اتجاه تقريبي اعتماداً على موقع القنيطرة. للحصول على دقة أفضل، فعّل الموقع ومعايرة البوصلة في هاتفك في إصدار لاحق.",hadithTitle:"أحاديث نبوية موثقة",settingsTitle:"الإعدادات",language:"اللغة",city:"المدينة",sound:"الصوت والاهتزاز",disclaimer:"مواقيت الصلاة تحتاج اتصالاً بالإنترنت. الأذكار والأحاديث المعروضة مختارة مع ذكر مصادرها. لا يغني التطبيق عن التحقق من التوقيت المحلي الرسمي.",navHome:"الرئيسية",navAdhkar:"الأذكار",navQibla:"القبلة",navHadith:"الأحاديث",navSettings:"الإعدادات",loading:"جارٍ تحميل المواقيت…",loaded:"تم تحديث المواقيت",failed:"تعذر تحميل المواقيت",source:"المصدر: خدمة مواقيت الصلاة · طريقة المغرب",today:"اليوم",done:"أحسنت! أتممت الهدف",repeat:"العدد",times:"مرة",read:"تم",morningDone:"أذكار الصباح",eveningDone:"أذكار المساء",hadithGrade:"حديث صحيح",quranTitle:"القرآن الكريم",navQuran:"القرآن",reciterLabel:"القارئ",searchSurah:"ابحث عن سورة",surahList:"سور القرآن الكريم · 114 سورة",quranIntro:"استمع إلى سور القرآن الكريم كاملة، واختر القارئ والسورة التي تحبها. يحتاج التشغيل إلى اتصال بالإنترنت.",searchPlaceholder:"اسم السورة أو رقمها",playSurah:"▶ تشغيل السورة",previousSurah:"السابق",nextSurah:"التالي"},
fr:{welcome:"Que la paix et la miséricorde de Dieu soient sur vous",tasbih:"Chapelet électronique",count:"Nombre de répétitions",tap:"Compter",undo:"Annuler",reset:"Réinitialiser",prayerTimes:"Heures de prière · Kénitra",dailyHadith:"Hadith du jour",adhkarTitle:"Invocations quotidiennes",morning:"Invocations du matin",evening:"Invocations du soir",afterPrayer:"Après la prière",qiblaTitle:"Direction de la Qibla",qiblaFrom:"Direction approximative depuis Kénitra",qiblaDesc:"Vers l’est, légèrement au sud",qiblaNotice:"Direction approximative depuis Kénitra. Une boussole calibrée et la localisation sont nécessaires pour une meilleure précision.",hadithTitle:"Hadiths référencés",settingsTitle:"Paramètres",language:"Langue",city:"Ville",sound:"Son et vibration",disclaimer:"Version initiale. Les horaires nécessitent Internet. Les invocations et hadiths sont accompagnés de leurs sources. Vérifiez les horaires officiels locaux.",navHome:"Accueil",navAdhkar:"Invocations",navQibla:"Qibla",navHadith:"Hadiths",navSettings:"Réglages",loading:"Chargement des horaires…",loaded:"Horaires actualisés",failed:"Horaires indisponibles",source:"Source : service des horaires · méthode Maroc",today:"Aujourd’hui",done:"Bravo ! Objectif atteint",repeat:"Répétitions",times:"fois",read:"Lu",morningDone:"Invocations du matin",eveningDone:"Invocations du soir",hadithGrade:"Authentique",quranTitle:"Le Saint Coran",navQuran:"Coran",reciterLabel:"Récitateur",searchSurah:"Rechercher une sourate",surahList:"Les sourates du Coran · 114",quranIntro:"Écoutez les sourates complètes et choisissez votre récitateur. Une connexion Internet est nécessaire.",searchPlaceholder:"Nom ou numéro de sourate",playSurah:"▶ Écouter la sourate",previousSurah:"Précédente",nextSurah:"Suivante"},
en:{welcome:"Peace and blessings be upon you",tasbih:"Digital Tasbih",count:"Dhikr count",tap:"Tap to count",undo:"Undo",reset:"Reset",prayerTimes:"Prayer times · Kenitra",dailyHadith:"Hadith of the day",adhkarTitle:"Daily adhkar",morning:"Morning adhkar",evening:"Evening adhkar",afterPrayer:"After prayer",qiblaTitle:"Qibla direction",qiblaFrom:"Approximate direction from Kenitra",qiblaDesc:"East, slightly toward the south",qiblaNotice:"Approximate direction based on Kenitra. Location access and a calibrated compass are needed for better accuracy.",hadithTitle:"Sourced Prophetic hadiths",settingsTitle:"Settings",language:"Language",city:"City",sound:"Sound and vibration",disclaimer:"Early version. Prayer times require internet. Adhkar and hadith include their sources. Please verify official local prayer times.",navHome:"Home",navAdhkar:"Adhkar",navQibla:"Qibla",navHadith:"Hadith",navSettings:"Settings",loading:"Loading prayer times…",loaded:"Prayer times updated",failed:"Prayer times unavailable",source:"Source: prayer-time service · Morocco method",today:"Today",done:"Well done! Goal completed",repeat:"Count",times:"times",read:"Done",morningDone:"Morning adhkar",eveningDone:"Evening adhkar",hadithGrade:"Authentic",quranTitle:"The Holy Quran",navQuran:"Quran",reciterLabel:"Reciter",searchSurah:"Search surah",surahList:"Quran surahs · 114",quranIntro:"Listen to complete Quran surahs and choose your reciter. An internet connection is required.",searchPlaceholder:"Surah name or number",playSurah:"▶ Play surah",previousSurah:"Previous",nextSurah:"Next"}
 };
const quranSurahs=[
"الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"
];
const preferredReciters=[
 {name:"العيون الكوشي",keys:["العيون الكوشي","العيون الكوشي المغربي","aloyoon al-koshi","aloyoon al koshi","alo-yoon al-koshi","koshi"]},
 {name:"عبد الرحمن السديس",keys:["عبد الرحمن السديس","السديس","abdul rahman al sudais","abdulrahman alsudaes"]},
 {name:"ماهر المعيقلي",keys:["ماهر المعيقلي","المعيقلي","maher al muaiqly","maher al meaqli"]},
 {name:"مشاري العفاسي",keys:["مشاري العفاسي","مشاري راشد العفاسي","العفاسي","mishary alafasy","mishary rashid alafasy"]},
 {name:"عبد الباسط عبد الصمد",keys:["عبد الباسط عبدالصمد","عبد الباسط عبد الصمد","abdulbasit abdulsamad","abdul basit abdul samad"]},
 {name:"محمود خليل الحصري",keys:["محمود خليل الحصري","الحصري","mahmoud khalil alhussary","mahmoud khalil al-hussary"]},
 {name:"محمد صديق المنشاوي",keys:["محمد صديق المنشاوي","المنشاوي","mohammed siddiq al-minshawi","mohammed siddiq al minshawi"]},
 {name:"سعود الشريم",keys:["سعود الشريم","الشريم","saud al-shuraim","saud al shuraim"]},
 {name:"فارس عباد",keys:["فارس عباد","fares abbad","fares abad"]},
 {name:"ياسر الدوسري",keys:["ياسر الدوسري","ياسر الدوسارى","yasser al-dosari","yasser al dosari"]},
 {name:"سعد الغامدي",keys:["سعد الغامدي","الغامدي","saad al-ghamdi","saad al ghamdi"]}
];
let quranReads=[], selectedSurah=Math.min(114,Math.max(1,Number(localStorage.getItem("s_quran_surah")||1))), selectedReadKey=localStorage.getItem("s_quran_read")||"";
function normalizeArabic(value){return String(value||"").normalize("NFD").replace(/[\u064B-\u065F\u0670\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();}
function renderSurahList(){const query=normalizeArabic($("quranSearch").value);const list=$("surahList");list.textContent="";quranSurahs.forEach((name,index)=>{const number=index+1;if(query&&!normalizeArabic(name).includes(query)&&!String(number).includes(query))return;const b=document.createElement("button");b.type="button";b.className="surah-item"+(number===selectedSurah?" active":"");b.setAttribute("aria-pressed",String(number===selectedSurah));const n=document.createElement("span");n.className="surah-number";n.textContent=number;const text=document.createElement("span");text.className="surah-name";text.textContent=name;const meta=document.createElement("span");meta.className="surah-meta";meta.textContent="سورة رقم "+number;text.appendChild(meta);b.append(n,text);b.onclick=()=>selectSurah(number,false);list.appendChild(b);});$("selectedSurahName").textContent="سورة "+quranSurahs[selectedSurah-1];}
function selectedRead(){return quranReads.find(r=>r.key===selectedReadKey)||quranReads[0]||null;}
function renderReciterSelect(){const select=$("quranReciter");select.textContent="";quranReads.forEach(read=>{const option=document.createElement("option");option.value=read.key;option.textContent=read.displayName;select.appendChild(option);});if(quranReads.length){if(!quranReads.some(r=>r.key===selectedReadKey))selectedReadKey=quranReads[0].key;select.value=selectedReadKey;localStorage.setItem("s_quran_read",selectedReadKey);$("selectedReciterName").textContent=selectedRead().displayName;}else{const option=document.createElement("option");option.value="";option.textContent="تعذر العثور على القراء";select.appendChild(option);}}
function parseAvailableSurahs(moshaf){
 const raw=moshaf.surah_list??moshaf.surahList??moshaf.surahs??[];
 let values=Array.isArray(raw)?raw.map(x=>Number(typeof x==="object"?(x.id??x.number):x)):
   String(raw||"").split(/[,،\s]+/).map(Number);
 values=values.filter(n=>Number.isInteger(n)&&n>=1&&n<=114);
 if(!values.length && Number(moshaf.surah_total)===114) values=Array.from({length:114},(_,i)=>i+1);
 return [...new Set(values)].sort((a,b)=>a-b);
}
function findPreferredReciter(records,wanted){
 const keys=wanted.keys.map(normalizeArabic).filter(Boolean);
 return records.find(r=>{
   const name=normalizeArabic(r.name);
   return keys.some(k=>name===k||name.includes(k)||k.includes(name)) && Array.isArray(r.moshaf)&&r.moshaf.some(m=>m.server);
 });
}
function buildQuranReads(records){
 const reads=[];
 for(const wanted of preferredReciters){
   const reciter=findPreferredReciter(records,wanted);
   if(!reciter) continue;
   const candidates=(reciter.moshaf||[]).filter(m=>m.server).map(m=>({m,available:parseAvailableSurahs(m)}));
   candidates.sort((a,b)=>b.available.length-a.available.length || (Number(b.m.surah_total)||0)-(Number(a.m.surah_total)||0));
   const chosen=candidates[0];
   if(!chosen||!chosen.available.length) continue;
   const moshaf=chosen.m;
   reads.push({key:String(reciter.id)+":"+String(moshaf.id),reciterId:reciter.id,moshafId:moshaf.id,
     displayName:wanted.name+(moshaf.name&&/ورش|warsh/i.test(moshaf.name)?" · ورش عن نافع":""),
     server:String(moshaf.server).replace(/\/?$/,"/"),available:chosen.available,total:chosen.available.length});
 }
 return reads;
}
async function loadQuranReciters(){
 const status=$("quranStatus"); status.textContent="جارٍ تحميل القراء والتحقق من السور المتاحة…";
 try{
   const response=await fetch("https://mp3quran.net/api/v3/reciters?language=ar",{cache:"no-store"});
   if(!response.ok) throw new Error("HTTP "+response.status);
   const data=await response.json(); if(!Array.isArray(data.reciters)) throw new Error("Invalid reciter data");
   try{localStorage.setItem("s_quran_reciters_cache",JSON.stringify(data.reciters));}catch(cacheError){}
   quranReads=buildQuranReads(data.reciters); renderReciterSelect();
   if(quranReads.length===preferredReciters.length){
     status.textContent="تم العثور على القراء الـ11 والتحقق من قائمة السور المتاحة لكل قارئ. اختر السورة ثم اضغط تشغيل.";
   }else{
     status.textContent="تم العثور على "+quranReads.length+" من أصل 11 قارئاً. بعض الأسماء أو التسجيلات غير متاحة حالياً؛ لن نعرض قائمة ناقصة على أنها مكتملة.";
   }
   updateSurahAvailability();
 }catch(error){
   try{
     const cached=JSON.parse(localStorage.getItem("s_quran_reciters_cache")||"[]");
     if(Array.isArray(cached)&&cached.length){quranReads=buildQuranReads(cached);renderReciterSelect();
       status.textContent="تعذر الاتصال بالمصدر؛ هذه قائمة محفوظة تضم "+quranReads.length+" من أصل 11 قارئاً. يلزم الإنترنت لتشغيل الصوت.";
       updateSurahAvailability(); return;
     }
   }catch(cacheError){}
   status.textContent="تعذر تحميل القراء. تحقق من الإنترنت وحاول مجدداً."; console.warn("Quran reciters load failed",error);
 }
}
function updateSurahAvailability(){const read=selectedRead();if(!read)return;const supported=read.available.includes(selectedSurah);$("quranStatus").textContent=supported?"القارئ جاهز لتلاوة هذه السورة.":"هذه السورة غير متوفرة في تسجيلات هذا القارئ. اختر سورة أخرى أو قارئاً آخر.";$("playSurah").disabled=!supported;$("playSurah").style.opacity=supported?"1":".5";}
function selectSurah(number,play){selectedSurah=Math.min(114,Math.max(1,Number(number)||1));localStorage.setItem("s_quran_surah",String(selectedSurah));renderSurahList();updateSurahAvailability();if(play)playSelectedSurah();}
async function playSelectedSurah(){const read=selectedRead();if(!read)return; if(!read.available.includes(selectedSurah)){updateSurahAvailability();return;}const audio=$("quranAudio");const url=read.server+String(selectedSurah).padStart(3,"0")+".mp3";audio.pause();audio.src=url;audio.load();$("quranStatus").textContent="جارٍ الاتصال بالتلاوة…";try{await audio.play();$("quranStatus").textContent="تُشغَّل الآن سورة "+quranSurahs[selectedSurah-1]+" بصوت "+read.displayName+".";}catch(error){$("quranStatus").textContent="تعذر بدء التشغيل. اضغط زر التشغيل في مشغل الصوت أو تحقق من الاتصال.";console.warn("Quran audio play failed",error);}}
function changeSurah(step){selectSurah(Math.min(114,Math.max(1,selectedSurah+step)),false);}

const hadiths=[
{ar:"إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.",fr:"Les actes ne valent que par les intentions, et chacun sera rétribué selon son intention.",en:"Actions are judged by intentions, and every person will get what they intended.",src:"صحيح البخاري 1؛ صحيح مسلم 1907",grade:"متفق عليه · صحيح"},
{ar:"من صلى عليَّ صلاةً صلى الله عليه بها عشراً.",fr:"Quiconque prie sur moi une fois, Allah lui accorde dix bénédictions.",en:"Whoever sends blessings upon me once, Allah sends ten blessings upon them.",src:"صحيح مسلم 408",grade:"صحيح"},
{ar:"الكلمة الطيبة صدقة.",fr:"Une bonne parole est une aumône.",en:"A good word is charity.",src:"صحيح البخاري 2989؛ صحيح مسلم 1009",grade:"متفق عليه · صحيح"},
{ar:"لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.",fr:"Aucun de vous ne croit vraiment jusqu’à ce qu’il aime pour son frère ce qu’il aime pour lui-même.",en:"None of you truly believes until he loves for his brother what he loves for himself.",src:"صحيح البخاري 13؛ صحيح مسلم 45",grade:"متفق عليه · صحيح"},
{ar:"الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ.",fr:"Le musulman est celui dont les musulmans sont à l’abri de la langue et de la main.",en:"A Muslim is the one from whose tongue and hand other Muslims are safe.",src:"صحيح البخاري 10؛ صحيح مسلم 40",grade:"متفق عليه · صحيح"},
{ar:"الطُّهُورُ شَطْرُ الْإِيمَانِ، وَالْحَمْدُ لِلَّهِ تَمْلَأُ الْمِيزَانَ.",fr:"La purification est la moitié de la foi, et « Al-hamdu lillah » remplit la balance.",en:"Purification is half of faith, and saying Alhamdulillah fills the scale.",src:"صحيح مسلم 223",grade:"صحيح"},
{ar:"وَأَنَّ أَحَبَّ الْأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ.",fr:"Les œuvres les plus aimées d’Allah sont celles qui sont régulières, même si elles sont peu nombreuses.",en:"The deeds most beloved to Allah are those done consistently, even if they are few.",src:"صحيح البخاري 6464",grade:"صحيح"}
];
const adhkar={
morning:[
{t:"أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.",n:1,s:"صحيح مسلم 2723"},
{t:"اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.",n:1,s:"سنن أبي داود 5068؛ جامع الترمذي 3391"},
{t:"سبحان الله وبحمده.",n:100,s:"صحيح البخاري 6405؛ صحيح مسلم 2691"},
{t:"آية الكرسي: الله لا إله إلا هو الحي القيوم...",n:1,s:"سورة البقرة، الآية 255"},
{t:"قل هو الله أحد، وقل أعوذ برب الفلق، وقل أعوذ برب الناس.",n:3,s:"سنن أبي داود 5082؛ جامع الترمذي 3575"},
{t:"رضيت بالله رباً، وبالإسلام ديناً، وبمحمد ﷺ نبياً.",n:3,s:"سنن أبي داود 5072؛ جامع الترمذي 3389"},
{t:"اللهم إني أسألك العفو والعافية في الدنيا والآخرة.",n:1,s:"سنن أبي داود 5074؛ جامع الترمذي 3511"}
],
evening:[
{t:"أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.",n:1,s:"صحيح مسلم 2723"},
{t:"اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير.",n:1,s:"سنن أبي داود 5068؛ جامع الترمذي 3391"},
{t:"سبحان الله وبحمده.",n:100,s:"صحيح البخاري 6405؛ صحيح مسلم 2691"},
{t:"آية الكرسي: الله لا إله إلا هو الحي القيوم...",n:1,s:"سورة البقرة، الآية 255"},
{t:"قل هو الله أحد، وقل أعوذ برب الفلق، وقل أعوذ برب الناس.",n:3,s:"سنن أبي داود 5082؛ جامع الترمذي 3575"},
{t:"أعوذ بكلمات الله التامات من شر ما خلق.",n:3,s:"صحيح مسلم 2708"},
{t:"رضيت بالله رباً، وبالإسلام ديناً، وبمحمد ﷺ نبياً.",n:3,s:"سنن أبي داود 5072؛ جامع الترمذي 3389"}
],
after:[
{t:"أستغفر الله.",n:3,s:"صحيح مسلم 591"},
{t:"اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام.",n:1,s:"صحيح مسلم 591"},
{t:"سبحان الله.",n:33,s:"صحيح مسلم 597"},
{t:"الحمد لله.",n:33,s:"صحيح مسلم 597"},
{t:"الله أكبر.",n:33,s:"صحيح مسلم 597"}
]};
let counts={};
try{
 counts=JSON.parse(localStorage.getItem("s_counts")||"{}");
 if(!counts||typeof counts!=="object"||Array.isArray(counts))counts={};
}catch(e){counts={};}
Object.keys(dhikrTypes).forEach(id=>{const n=Number(counts[id]);counts[id]=Number.isFinite(n)&&n>0?Math.floor(n):0;});
if(!localStorage.getItem("s_counts")&&Number(localStorage.getItem("s_count")||0)>0){counts.tasbih=Math.floor(Number(localStorage.getItem("s_count"))||0);}
let currentDhikr=localStorage.getItem("s_current_dhikr")||"tasbih";
if(!dhikrTypes[currentDhikr])currentDhikr="tasbih";
let count=counts[currentDhikr], savedTarget=Number(localStorage.getItem("s_target")||33), target=[33,99,1000].includes(savedTarget)?savedTarget:33, kind="morning", lang=localStorage.getItem("s_lang")||"ar";
if(!translations[lang])lang="ar";
const $=id=>document.getElementById(id);
const fajrToggle=$("fajrReminder");
fajrToggle.checked=localStorage.getItem("s_fajr_reminder")==="1";
fajrToggle.addEventListener("change",()=>{localStorage.setItem("s_fajr_reminder",fajrToggle.checked?"1":"0");if(!fajrToggle.checked){if(window.SobhatiAndroid)SobhatiAndroid.cancelFajrReminder();return;}if(window.SobhatiAndroid)SobhatiAndroid.requestNotificationPermission();scheduleFajrFromCache();});
const quranNotificationsToggle=$("quranNotifications"),quranDailyCount=$("quranDailyCount");quranNotificationsToggle.checked=localStorage.getItem("s_quran_notifications")==="1";quranDailyCount.value=localStorage.getItem("s_quran_daily_count")||"3";function updateQuranNotifications(){const enabled=quranNotificationsToggle.checked,count=Number(quranDailyCount.value)||3;localStorage.setItem("s_quran_notifications",enabled?"1":"0");localStorage.setItem("s_quran_daily_count",String(count));if(!window.SobhatiAndroid)return;if(enabled){SobhatiAndroid.requestNotificationPermission();SobhatiAndroid.scheduleQuranNotifications(count);}else{SobhatiAndroid.cancelQuranNotifications();}}quranNotificationsToggle.addEventListener("change",updateQuranNotifications);quranDailyCount.addEventListener("change",()=>{if(quranNotificationsToggle.checked)updateQuranNotifications();});
function scheduleFajrFromCache(){if(!fajrToggle.checked||!window.SobhatiAndroid)return;try{const c=JSON.parse(localStorage.getItem("s_prayer_cache")||"null");if(!c||!c.timings||!c.timings.Fajr)return;const parts=String(c.timings.Fajr).match(/(\d{1,2}):(\d{2})/);if(!parts)return;const now=new Date(),fajr=new Date(now.getFullYear(),now.getMonth(),now.getDate(),Number(parts[1]),Number(parts[2]),0,0);SobhatiAndroid.scheduleFajrReminder(fajr.getTime());}catch(e){console.warn("Fajr reminder scheduling failed",e);}}
function saveCounts(){localStorage.setItem("s_counts",JSON.stringify(counts));}
function saveCurrentCount(){counts[currentDhikr]=count;saveCounts();}
function selectDhikr(id){if(!dhikrTypes[id])return;saveCurrentCount();currentDhikr=id;localStorage.setItem("s_current_dhikr",id);count=counts[id];document.querySelectorAll("[data-dhikr]").forEach(b=>{const active=b.dataset.dhikr===id;b.classList.toggle("active",active);b.setAttribute("aria-pressed",String(active));b.textContent=dhikrTypes[id].label[lang]&&active?dhikrTypes[id].label[lang]:dhikrTypes[b.dataset.dhikr].label[lang];});renderCount();}
function t(k){return translations[lang][k]||translations.ar[k]||k}
function setLang(v){lang=v;localStorage.setItem("s_lang",v);$("lang").value=v;$("lang2").value=v;document.documentElement.lang=v;document.documentElement.dir=v==="ar"?"rtl":"ltr";document.querySelectorAll("[data-i]").forEach(e=>e.textContent=t(e.dataset.i));document.querySelectorAll("[data-i-placeholder]").forEach(e=>e.placeholder=t(e.dataset.iPlaceholder));document.querySelectorAll("[data-dhikr]").forEach(b=>{b.textContent=dhikrTypes[b.dataset.dhikr].label[lang];b.classList.toggle("active",b.dataset.dhikr===currentDhikr);b.setAttribute("aria-pressed",String(b.dataset.dhikr===currentDhikr));});$("welcome").textContent=t("welcome");$("tap").textContent=t("tap");$("prayerNote").textContent=t("source");$("prayerStatus").textContent=$("prayerStatus").dataset.ok==="1"?t("loaded"):$("prayerStatus").dataset.fail==="1"?t("failed"):t("loading");renderAdhkar();renderHadiths();renderCount();$("today").textContent=new Date().toLocaleDateString(v==="ar"?"ar-MA":v==="fr"?"fr-FR":"en-GB",{weekday:"long",year:"numeric",month:"long",day:"numeric"});}
function renderCount(){$("count").textContent=count;$("currentDhikrLabel").textContent=dhikrTypes[currentDhikr].text;$("goalText").textContent=count+" / "+target;$("bar").style.width=Math.min(100,count/target*100)+"%";document.querySelectorAll("[data-target]").forEach(b=>b.classList.toggle("active",Number(b.dataset.target)===target));}
document.querySelectorAll("[data-dhikr]").forEach(b=>{b.setAttribute("aria-pressed",String(b.dataset.dhikr===currentDhikr));b.onclick=()=>selectDhikr(b.dataset.dhikr);});
$("tap").onclick=()=>{count++;saveCurrentCount();renderCount();if($("vibrate").checked&&navigator.vibrate)navigator.vibrate(25);if(count===target)alert(t("done"))};
$("undo").onclick=()=>{count=Math.max(0,count-1);saveCurrentCount();renderCount()};
$("reset").onclick=()=>{if(confirm(t("reset")+"?")){count=0;saveCurrentCount();renderCount()}};
document.querySelectorAll("[data-target]").forEach(b=>b.onclick=()=>{target=+b.dataset.target;localStorage.setItem("s_target",target);document.querySelectorAll("[data-target]").forEach(x=>x.classList.toggle("active",x===b));renderCount()});
function adhkarProgressKey(){return "s_adhkar_done_"+new Date().toISOString().slice(0,10);}
function getAdhkarDone(){try{return JSON.parse(localStorage.getItem(adhkarProgressKey())||"{}")||{};}catch(e){return {};}}
function toggleAdhkarDone(key){const done=getAdhkarDone();done[key]=!done[key];localStorage.setItem(adhkarProgressKey(),JSON.stringify(done));renderAdhkar();}
function renderAdhkar(){const arr=adhkar[kind],done=getAdhkarDone();const readLabel=lang==="ar"?"تمت القراءة":lang==="fr"?"Lu":"Read";const undoLabel=lang==="ar"?"إلغاء":lang==="fr"?"Annuler":"Undo";const repeatLabel=lang==="ar"?"التكرار":lang==="fr"?"Répétitions":"Repeat";$("adhkarList").innerHTML=arr.map((x,i)=>{const key=kind+"_"+i,checked=!!done[key];return `<article class="card" style="margin:10px 0"><div class="row"><span class="muted">${repeatLabel}: ${x.n}</span><button class="chip ${checked?"active":""}" type="button" aria-pressed="${checked}" onclick="toggleAdhkarDone('${key}')">${checked?"✓ "+undoLabel:readLabel}</button></div><div class="dhikr">${x.t}</div><div class="source">${x.s}</div></article>`;}).join("");}
document.querySelectorAll("[data-kind]").forEach(b=>b.onclick=()=>{kind=b.dataset.kind;document.querySelectorAll("[data-kind]").forEach(x=>x.classList.toggle("active",x===b));renderAdhkar()});
function renderHadiths(){$("hadithList").innerHTML=hadiths.map((h,i)=>`<article class="card" style="margin:10px 0"><div class="muted">${h.grade}</div><div class="hadith">${h[lang]}</div><div class="source">${h.src}</div></article>`).join("");const h=hadiths[(new Date().getDate()-1)%hadiths.length];$("hadithText").textContent=h[lang];$("hadithSource").textContent=h.src;$("hadithGrade").textContent=h.grade}
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav button").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id===b.dataset.view));});
$("lang").onchange=e=>setLang(e.target.value);$("lang2").onchange=e=>setLang(e.target.value);
async function loadPrayer(){const names={Fajr:"الفجر",Sunrise:"الشروق",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};try{let d=new Date(),url=`https://api.aladhan.com/v1/timingsByCity/${d.getDate()}-${d.getMonth()+1}-${d.getFullYear()}?city=Kenitra&country=Morocco&method=21`;let r=await fetch(url),j=await r.json();if(j.code!==200)throw Error();let tm=j.data.timings, keys=["Fajr","Dhuhr","Asr","Maghrib","Isha"];try{localStorage.setItem("s_prayer_cache",JSON.stringify({timings:tm,date:j.data.date.readable}));scheduleFajrFromCache();}catch(cacheError){}$("prayers").innerHTML=keys.map(k=>`<div class="prayer"><b>${lang==="ar"?names[k]:({Fajr:"Fajr",Dhuhr:"Dhuhr",Asr:"Asr",Maghrib:"Maghrib",Isha:"Isha"}[k])}</b><span>${tm[k]}</span></div>`).join("");$("prayerDate").textContent=j.data.date.readable;$("prayerStatus").dataset.ok="1";$("prayerStatus").textContent=t("loaded");}catch(e){try{const cached=JSON.parse(localStorage.getItem("s_prayer_cache")||"null");if(cached&&cached.timings){scheduleFajrFromCache();const tm=cached.timings,keys=["Fajr","Dhuhr","Asr","Maghrib","Isha"],names={Fajr:"الفجر",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};$("prayers").innerHTML=keys.map(k=>`<div class="prayer"><b>${lang==="ar"?names[k]:k}</b><span>${tm[k]}</span></div>`).join("");$("prayerDate").textContent=cached.date||"آخر تحديث محفوظ";$("prayerStatus").textContent="مواقيت محفوظة دون اتصال";return;}}catch(cacheError){}$("prayerStatus").dataset.fail="1";$("prayerStatus").textContent=t("failed");$("prayers").innerHTML='<div class="muted" style="grid-column:1/-1">يرجى التحقق من الاتصال بالإنترنت ثم إعادة فتح التطبيق.</div>'}}
$("quranSearch").addEventListener("input",renderSurahList);
$("quranReciter").addEventListener("change",()=>{selectedReadKey=$("quranReciter").value;localStorage.setItem("s_quran_read",selectedReadKey);const read=selectedRead();$("selectedReciterName").textContent=read?read.displayName:"";$("quranAudio").pause();$("quranAudio").removeAttribute("src");updateSurahAvailability();});
$("playSurah").addEventListener("click",playSelectedSurah);
$("previousSurah").addEventListener("click",()=>changeSurah(-1));$("nextSurah").addEventListener("click",()=>changeSurah(1));
$("quranAudio").addEventListener("error",()=>{$("quranStatus").textContent="تعذر تحميل هذه التلاوة من الخادم. جرّب قارئاً آخر أو سورة أخرى، وتحقق من اتصال الإنترنت.";});
$("quranAudio").addEventListener("ended",()=>{$("quranStatus").textContent="انتهت تلاوة سورة "+quranSurahs[selectedSurah-1]+".";});
renderSurahList();loadQuranReciters();
$("today").textContent=new Date().toLocaleDateString(lang==="ar"?"ar-MA":lang==="fr"?"fr-FR":"en-GB",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
window.addEventListener("pagehide",saveCurrentCount);
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden")saveCurrentCount();});
setLang(lang);renderCount();loadPrayer();
