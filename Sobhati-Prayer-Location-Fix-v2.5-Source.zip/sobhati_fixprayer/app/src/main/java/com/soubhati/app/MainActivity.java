package com.soubhati.app;

import android.Manifest;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.GeomagneticField;
import android.os.Looper;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 710;
    private static final int LOCATION_PERMISSION_REQUEST = 711;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private LocationManager locationManager;
    private Location currentLocation;
    private float magneticAzimuth = Float.NaN;
    private boolean qiblaActive = false;
    private boolean prayerLocationRequested = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false); settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new ReminderBridge(), "SobhatiAndroid");
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        webView.setBackgroundColor(0xFFF4F7F2);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) { return assetLoader.shouldInterceptRequest(request.getUrl()); }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private class ReminderBridge {
        @JavascriptInterface public void requestPrayerLocation() {
            runOnUiThread(() -> {
                prayerLocationRequested = true;
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
                else fetchPrayerLocation();
            });
        }
        @JavascriptInterface public void requestQibla() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
                } else startQiblaSensors();
            });
        }
        @JavascriptInterface public void stopQibla() { runOnUiThread(() -> stopQiblaSensors()); }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    if (!manager.canScheduleExactAlarms()) {
                        Intent permissionIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        try { startActivity(permissionIntent); } catch (Exception ignored) { }
                    }
                }
            });
        }
        @JavascriptInterface public void scheduleFajrReminder(long fajrMillis) {
            if (fajrMillis <= 0) return;
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putLong("next_fajr", fajrMillis).putBoolean("fajr_enabled", true).apply();
            scheduleSavedFajrReminder();
        }
        @JavascriptInterface public void scheduleQuranNotifications(int dailyCount) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
                int count = Math.max(1, Math.min(6, dailyCount));
                getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("quran_enabled", true).putInt("quran_daily_count", count).putInt("quran_sent_today", 0).putString("quran_day", java.time.LocalDate.now().toString()).apply();
                QuranNotificationReceiver.scheduleNext(MainActivity.this, true);
            });
        }
        @JavascriptInterface public void cancelQuranNotifications() {
            QuranNotificationReceiver.cancel(MainActivity.this);
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("quran_enabled", false).apply();
        }
        @JavascriptInterface public void cancelFajrReminder() {
            Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pending = PendingIntent.getBroadcast(MainActivity.this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pending);
            getSharedPreferences("sobhati_reminders", MODE_PRIVATE).edit().putBoolean("fajr_enabled", false).remove("next_fajr").apply();
        }
    }
    private void scheduleSavedFajrReminder() {
        android.content.SharedPreferences prefs = getSharedPreferences("sobhati_reminders", MODE_PRIVATE);
        if (!prefs.getBoolean("fajr_enabled", false)) return;
        long fajrMillis = prefs.getLong("next_fajr", 0L);
        if (fajrMillis <= 0L) return;
        long triggerAt = fajrMillis - 10L * 60L * 1000L;
        while (triggerAt <= System.currentTimeMillis()) {
            fajrMillis += 24L * 60L * 60L * 1000L;
            triggerAt = fajrMillis - 10L * 60L * 1000L;
        }
        prefs.edit().putLong("next_fajr", fajrMillis).apply();
        AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) return;
        Intent intent = new Intent(this, ReminderReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(this, 100, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending);
        else alarm.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pending);
    }

    @Override protected void onResume() {
        super.onResume();
        // Returning from Android's exact-alarm settings screen should restore the pending alarm.
        scheduleSavedFajrReminder();
    }

    private void fetchPrayerLocation() {
        try {
            Location last = null;
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) sendPrayerLocation(last);
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, this, Looper.getMainLooper());
            if (last == null) sendPrayerLocationStatus("جارٍ تحديد موقعك… تأكد من تشغيل خدمة الموقع");
        } catch (SecurityException e) { sendPrayerLocationStatus("يرجى السماح بالوصول إلى موقعك لحساب مواقيت الصلاة"); }
          catch (Exception e) { sendPrayerLocationStatus("تعذر تحديد الموقع؛ تحقق من تشغيل GPS"); }
    }
    private void sendPrayerLocation(Location location) {
        if (!prayerLocationRequested || location == null || webView == null) return;
        currentLocation = location;
        String js = String.format(java.util.Locale.US, "window.onPrayerLocation && window.onPrayerLocation(%.6f,%.6f,%.1f)", location.getLatitude(), location.getLongitude(), location.getAccuracy());
        webView.post(() -> webView.evaluateJavascript(js, null)); prayerLocationRequested = false;
        try { locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
    }
    private void sendPrayerLocationStatus(String message) { if (webView != null) webView.post(() -> webView.evaluateJavascript("window.onPrayerLocationStatus && window.onPrayerLocationStatus(" + org.json.JSONObject.quote(message) + ")", null)); }

    private void startQiblaSensors() {
        qiblaActive = true;
        if (rotationSensor != null) sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI);
        else sendQiblaStatus("لا يتوفر حساس اتجاه في هذا الهاتف");
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last == null) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (last != null) { currentLocation = last; updateQibla(); }
                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 1f, this, Looper.getMainLooper());
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 5f, this, Looper.getMainLooper());
                if (currentLocation == null) sendQiblaStatus("في انتظار تحديد موقعك… تأكد من تشغيل GPS");
            } else if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Location last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (last != null) { currentLocation = last; updateQibla(); }
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 10f, this, Looper.getMainLooper());
            }
        } catch (SecurityException ignored) { sendQiblaStatus("يرجى السماح بالوصول إلى الموقع"); }
          catch (IllegalArgumentException ignored) { sendQiblaStatus("تعذر تشغيل مزود الموقع في هذا الهاتف"); }
    }
    private void stopQiblaSensors() {
        qiblaActive = false;
        sensorManager.unregisterListener(this);
        try { locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
    }
    private void sendQiblaStatus(String message) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript("window.onQiblaStatus && window.onQiblaStatus(" + org.json.JSONObject.quote(message) + ")", null));
    }
    private void updateQibla() {
        if (!qiblaActive || currentLocation == null || Float.isNaN(magneticAzimuth)) return;
        double lat1 = Math.toRadians(currentLocation.getLatitude());
        double lon1 = Math.toRadians(currentLocation.getLongitude());
        double lat2 = Math.toRadians(21.422487);
        double lon2 = Math.toRadians(39.826206);
        double dLon = lon2 - lon1;
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        double bearing = (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
        GeomagneticField field = new GeomagneticField((float)currentLocation.getLatitude(), (float)currentLocation.getLongitude(), (float)currentLocation.getAltitude(), System.currentTimeMillis());
        double trueAzimuth = (magneticAzimuth + field.getDeclination() + 360.0) % 360.0;
        double relative = (bearing - trueAzimuth + 360.0) % 360.0;
        String js = String.format(java.util.Locale.US, "window.onQiblaUpdate && window.onQiblaUpdate(%.6f,%.6f,%.2f,%.2f,%.2f)", currentLocation.getLatitude(), currentLocation.getLongitude(), bearing, trueAzimuth, relative);
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }
    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] matrix = new float[9]; SensorManager.getRotationMatrixFromVector(matrix, event.values);
            float[] orientation = new float[3]; SensorManager.getOrientation(matrix, orientation);
            magneticAzimuth = (float)((Math.toDegrees(orientation[0]) + 360.0) % 360.0);
            updateQibla();
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) sendQiblaStatus("دقة البوصلة ضعيفة؛ حرّك الهاتف بشكل رقم 8 لمعايرتها");
    }
    @Override public void onLocationChanged(Location location) { currentLocation = location; if (prayerLocationRequested) sendPrayerLocation(location); updateQibla(); }
    @Override public void onProviderDisabled(String provider) { sendQiblaStatus("خدمة الموقع متوقفة؛ فعّل GPS"); }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) { if (prayerLocationRequested) fetchPrayerLocation(); else startQiblaSensors(); } else { prayerLocationRequested = false; sendQiblaStatus("لم يتم منح إذن الموقع؛ لا يمكن تحديد القبلة بدقة"); sendPrayerLocationStatus("لم يتم منح إذن الموقع؛ لا يمكن حساب مواقيت الصلاة حسب موقعك"); }
        } else if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            // The alarm remains scheduled; Android will display notifications once permission is granted.
            scheduleSavedFajrReminder();
            android.content.SharedPreferences prefs = getSharedPreferences("sobhati_reminders", MODE_PRIVATE);
            if (prefs.getBoolean("quran_enabled", false)) QuranNotificationReceiver.scheduleNext(this, true);
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { stopQiblaSensors(); if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
