const vm=require('vm'); const ctx={}; vm.createContext(ctx); vm.runInContext(`const quranSurahs=[
"الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"
];
function normalizeArabic(value){return String(value||"").normalize("NFD").replace(/[\u064B-\u065F\u0670\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();}
const preferredReciters=[
 {name:"العيون الكوشي",keys:["العيون الكوشي","العيون الكوشي المغربي","aloyoon al-koshi","aloyoon al koshi","alo-yoon al-koshi","koshi"]},
 {name:"عبد الرحمن السديس",keys:["عبد الرحمن السديس","السديس","abdul rahman al sudais","abdulrahman alsudaes"]},
 {name:"ماهر المعيقلي",keys:["ماهر المعيقلي","المعيقلي","maher al muaiqly","maher al meaqli"]},
 {name:"مشاري العفاسي",keys:["مشاري العفاسي","مشاري راشد العفاسي","العفاسي","mishary alafasy","mishary rashid alafasy"]},
 {name:"عبد الباسط عبد الصمد",keys:["عبد الباسط عبدالصمد","عبد الباسط عبد الصمد","abdulbasit abdulsamad","abdul basit abdul samad"]},
 {name:"محمود خليل الحصري",keys:["محمود خليل الحصري","الحصري","mahmoud khalil alhussary","mahmoud khalil al-hussary"]},
 {name:"محمد صديق المنشاوي",keys:["محمد صديق المنشاوي","المنشاوي","mohammed siddiq al-minshawi","mohammed siddiq al minshawi"]},
 {name:"سعود الشريم",keys:["سعود الشريم","الشريم","saud al-shuraim","saud al shuraim"]},
 {name:"فارس عباد",keys:["فارس عباد","fares abbad","fares abad"]},
 {name:"ياسر الدوسري",keys:["ياسر الدوسري","ياسر الدوسارى","yasser al-dosari","yasser al dosari"]},
 {name:"سعد الغامدي",keys:["سعد الغامدي","الغامدي","saad al-ghamdi","saad al ghamdi"]}
];
let quranReads=[], selectedSurah=Math.min(114,Math.max(1,Number(localStorage.getItem("s_quran_surah")||1))), selectedReadKey=localStorage.getItem("s_quran_read")||"";
function normalizeArabic(value){return String(value||"").normalize("NFD").replace(/[\u064B-\u065F\u0670\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();}
function renderSurahList(){const query=normalizeArabic($("quranSearch").value);const list=$("surahList");list.textContent="";quranSurahs.forEach((name,index)=>{const number=index+1;if(query&&!normalizeArabic(name).includes(query)&&!String(number).includes(query))return;const b=document.createElement("button");b.type="button";b.className="surah-item"+(number===selectedSurah?" active":"");b.setAttribute("aria-pressed",String(number===selectedSurah));const n=document.createElement("span");n.className="surah-number";n.textContent=number;const text=document.createElement("span");text.className="surah-name";text.textContent=name;const meta=document.createElement("span");meta.className="surah-meta";meta.textContent="سورة رقم "+number;text.appendChild(meta);b.append(n,text);b.onclick=()=>selectSurah(number,false);list.appendChild(b);});$("selectedSurahName").textContent="سورة "+quranSurahs[selectedSurah-1];}
function selectedRead(){return quranReads.find(r=>r.key===selectedReadKey)||quranReads[0]||null;}
function renderReciterSelect(){const select=$("quranReciter");select.textContent="";quranReads.forEach(read=>{const option=document.createElement("option");option.value=read.key;option.textContent=read.displayName;select.appendChild(option);});if(quranReads.length){if(!quranReads.some(r=>r.key===selectedReadKey))selectedReadKey=quranReads[0].key;select.value=selectedReadKey;localStorage.setItem("s_quran_read",selectedReadKey);$("selectedReciterName").textContent=selectedRead().displayName;}else{const option=document.createElement("option");option.value="";option.textContent="تعذر العثور على القراء";select.appendChild(option);}}
function parseAvailableSurahs(moshaf){
 const raw=moshaf.surah_list??moshaf.surahList??moshaf.surahs??[];
 let values=Array.isArray(raw)?raw.map(x=>Number(typeof x==="object"?(x.id??x.number):x)):
   String(raw||"").split(/[,،\s]+/).map(Number);
 values=values.filter(n=>Number.isInteger(n)&&n>=1&&n<=114);
 if(!values.length && Number(moshaf.surah_total)===114) values=Array.from({length:114},(_,i)=>i+1);
 return [...new Set(values)].sort((a,b)=>a-b);
}
function findPreferredReciter(records,wanted){
 const keys=wanted.keys.map(normalizeArabic).filter(Boolean);
 return records.find(r=>{
   const name=normalizeArabic(r.name);
   return keys.some(k=>name===k||name.includes(k)||k.includes(name)) && Array.isArray(r.moshaf)&&r.moshaf.some(m=>m.server);
 });
}
function buildQuranReads(records){
 const reads=[];
 for(const wanted of preferredReciters){
   const reciter=findPreferredReciter(records,wanted);
   if(!reciter) continue;
   const candidates=(reciter.moshaf||[]).filter(m=>m.server).map(m=>({m,available:parseAvailableSurahs(m)}));
   candidates.sort((a,b)=>b.available.length-a.available.length || (Number(b.m.surah_total)||0)-(Number(a.m.surah_total)||0));
   const chosen=candidates[0];
   if(!chosen||!chosen.available.length) continue;
   const moshaf=chosen.m;
   reads.push({key:String(reciter.id)+":"+String(moshaf.id),reciterId:reciter.id,moshafId:moshaf.id,
     displayName:wanted.name+(moshaf.name&&/ورش|warsh/i.test(moshaf.name)?" · ورش عن نافع":""),
     server:String(moshaf.server).replace(/\/?$/,"/"),available:chosen.available,total:chosen.available.length});
 }
 return reads;
}
this.result={surahs:quranSurahs.length,preferred:preferredReciters.length,reads:buildQuranReads(preferredReciters.map((w,i)=>({id:i+1,name:w.keys[0],moshaf:[{id:i+100,server:'https://audio.example/'+i+'/',surah_total:114,surah_list:Array.from({length:114},(_,j)=>j+1).join(',')}]})))};`,ctx);
if(ctx.result.surahs!==114||ctx.result.preferred!==11||ctx.result.reads.length!==11||ctx.result.reads.some(x=>x.available.length!==114)) throw new Error(JSON.stringify({surahs:ctx.result.surahs,preferred:ctx.result.preferred,reads:ctx.result.reads.length}));
console.log('PASS: 114 surahs; 11 reciter definitions; 11/11 mock API records matched; 114/114 availability per mock record');
