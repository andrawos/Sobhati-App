# سُبْحَتِي — مشروع Android

تطبيق أذكار وسبحة إلكترونية يعمل داخل Android WebView.

## الإصدار 1.4
- ستة أنواع للذكر: التسبيح، الاستغفار، التهليل، التكبير، الحوقلة، والصلاة على النبي ﷺ.
- حفظ عدّاد كل نوع بشكل مستقل على الجهاز، مع التراجع والتصفير والأهداف 33 و99 و1000.
- أذكار الصباح والمساء وما بعد الصلاة، وأحاديث مع مصادرها.
- صفحة القرآن الكريم: قائمة السور الـ114، البحث باسم السورة أو رقمها، اختيار قارئ، وبث تلاوة السورة كاملة مع مشغل صوت.
- 11 قارئاً مفضلاً، من ضمنهم القارئ المغربي العيون الكوشي برواية ورش عن نافع، مع تحميل بيانات روابط التلاوات من واجهة MP3Quran.net الرسمية.
- واجهة بثلاث لغات: العربية والفرنسية والإنجليزية.
- مواقيت الصلاة لمدينة القنيطرة عبر الإنترنت.
- تنبيه الفجر قبل الموعد بعشر دقائق عبر Android AlarmManager، مع إعادة الجدولة بعد إعادة تشغيل الهاتف.
- إشعارات آيات قرآنية مجدولة محلياً، آية واحدة لكل إشعار، مع اسم السورة ورقم الآية، وتعمل دون اتصال بعد تفعيلها.

## ملاحظات القرآن والصوت
- تشغيل التلاوات يحتاج اتصالاً بالإنترنت؛ لا يتم تنزيل ملفات الصوت داخل APK.
- قائمة القراء وروابط التسجيلات تُحمّل من MP3Quran.net API، ويعرض التطبيق السور المتاحة فعلياً لكل قارئ حسب بيانات المصدر.
- رواية القارئ العيون الكوشي في المصدر هي ورش عن نافع، وهي مناسبة للاستخدام الشائع في المغرب.
- ملفات التلاوات مستضافة لدى مزوّد المصدر؛ لم نضمّنها داخل المشروع ولم ننسب ملكيتها إلى التطبيق.

## بناء APK عبر GitHub Actions
1. ارفع ملف المشروع ZIP الوحيد إلى المستودع مع الاسم الذي يتوقعه Workflow الحالي.
2. افتح تبويب Actions.
3. شغّل Workflow الخاص ببناء Sobhati APK أو ادفع commit إلى الفرع `main`.
4. بعد نجاح التشغيل، افتح Artifacts ونزّل ملف APK.
5. ثبّت APK على هاتف Android واختبر عدّادات الأذكار وتشغيل السور.

## ملاحظات أخرى
- مواقيت الصلاة تحتاج اتصالاً بالإنترنت، ويجب مطابقتها مع التوقيت المحلي الرسمي.
- اتجاه القبلة المعروض تقريبي وثابت، وليس قراءة مباشرة من بوصلة الهاتف أو حساساته.
- نصوص الأذكار تبقى بالعربية حتى عند تغيير لغة واجهة التطبيق.
- بيانات عدّاد الذكر تحفظ محلياً داخل التطبيق.


## Version 1.6 – Adhkar and Tasbih update

- Added an independent seventh counter option: **الحمد لله**.
- Each dhikr counter is saved independently in local storage and the selected counter is restored on reopening.
- Expanded morning and evening adhkar with additional narrations and source references.
- Added daily completion toggles for each adhkar; completion state is saved by date and can be undone.
- Updated language switching so the selected counter button state remains correct.

Validation performed for this update: JavaScript syntax check (`node --check`) passed. An Android APK build and on-device interaction test have not yet been performed in this environment.


## Version 1.8 – Quran reciter and playback reliability

- Retained the complete 114-surah Arabic list and verified its item count in the source.
- Retained the requested 11-reciter shortlist, including the Moroccan reciter الشيخ العيون الكوشي.
- Added Arabic and Latin transliteration aliases for matching reciters returned by MP3Quran.net.
- Fixed Arabic normalization so diacritics and hamza variants are normalized correctly.
- Improved selection of the recitation edition by preferring the edition with the largest explicitly listed surah coverage.
- Added safe parsing for the API's available-surah list and a 114-surah fallback only when the API explicitly reports `surah_total = 114`.
- The UI now reports the actual number of matched reciters instead of claiming that all 11 loaded when fewer are returned.
- Preserved per-reciter/per-surah availability checks and clearer playback error feedback.

Validation: inline JavaScript syntax check passed; source-level test verified 114 surah entries and all 11 preferred reciter definitions. Live API/network playback and Android-device playback could not be tested in this environment; they remain required before claiming end-to-end success.


## الإصدار 1.9 — إصلاح القبلة

- استبدال زاوية القبلة الثابتة بحساب اتجاه القبلة نحو الكعبة (21.422487, 39.826206) انطلاقاً من إحداثيات الهاتف.
- طلب إذن الموقع أثناء الاستخدام، مع دعم الموقع الدقيق أو التقريبي.
- استخدام حساس Rotation Vector لحساب اتجاه الهاتف، وتصحيح الشمال المغناطيسي بالانحراف المغناطيسي المحلي.
- تحديث سهم البوصلة والزاوية بصورة مباشرة، وإيقاف مستشعرات الموقع والبوصلة عند مغادرة شاشة القبلة.
- إضافة رسائل توضيحية عند رفض الإذن أو غياب الحساس أو توقف خدمة الموقع.

**حدود التحقق:** تم فحص JavaScript وإنشاء المصدر المضغوط. لم يتم بناء APK في هذه البيئة لعدم توفر Android SDK/Gradle، ولم يتم اختبار الحساسات على هاتف فعلي؛ يلزم ذلك قبل إعلان اجتياز اختبار الجهاز.


## الإصدار 2.0 — تحسين تنبيهات الفجر والقرآن

- إعادة جدولة منبه الفجر المحفوظ عند العودة إلى التطبيق بعد منح صلاحية المنبهات الدقيقة في Android 12 وما بعده.
- إعادة محاولة تفعيل منبه الفجر وإشعارات القرآن بعد نتيجة طلب صلاحية الإشعارات.
- إصلاح توقف إشعارات الآيات بعد بلوغ العدد اليومي: يتم الآن جدولة بداية اليوم التالي بدلاً من التوقف نهائياً.
- حصر إشعارات الآيات في نافذة نهارية تقريبية من 09:00 إلى 21:00 بالتوقيت المحلي، مع احترام العدد اليومي المختار (1 إلى 6).
- استمرار إعادة جدولة التنبيهات بعد إعادة تشغيل الهاتف.

**حدود التحقق:** فحص JavaScript نجح، وفُحصت تغييرات Java وManifest يدوياً. لم يتوفر Gradle أو Android SDK في بيئة العمل، لذلك لم يتم بناء APK أو اختبار وصول الإشعارات فعلياً على جهاز Android. كما أن مواقيت الصلاة في واجهة المشروع لا تزال مرتبطة بمدينة القنيطرة؛ يلزم إصلاح تحديد المدينة/الموقع قبل اعتماد تنبيه الفجر للمستخدمين في مدن أخرى.


## الإصدار 2.1 — الهوية البصرية والأيقونة

- إنشاء أيقونة Android موحدة بخلفية خضراء داكنة وتفاصيل ذهبية وهلال وقوس معماري واسم سبحتي.
- إضافة أيقونات launcher التقليدية بمقاسات mdpi إلى xxxhdpi، وأيقونة adaptive للأجهزة الحديثة.
- ربط الأيقونة واسم التطبيق وTheme مخصص في AndroidManifest.
- تحسين رأس الواجهة بإظهار الشعار المصغر وتوحيد اللون الأخضر والذهبي.
- الاحتفاظ بالوظائف السابقة دون الادعاء باختبارها على جهاز فعلي.

التحقق: تم فحص XML ووجود كل ملفات الأيقونات ومرجع الشعار داخل HTML. لم يتم بناء APK في هذه البيئة لعدم توفر Android SDK/Gradle.
